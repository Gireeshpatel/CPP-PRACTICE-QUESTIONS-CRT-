# C++ Practice Questions (with answers)

Solutions for every question. Try each one yourself first, then compare.

## Set 1 - Formulas and Conversions

- [q01_rectangle_garden.cpp](set1_formulas_conversions/q01_rectangle_garden.cpp) - Rectangle garden
- [q02_square_playground.cpp](set1_formulas_conversions/q02_square_playground.cpp) - Square playground
- [q03_circle_fountain.cpp](set1_formulas_conversions/q03_circle_fountain.cpp) - Circle fountain
- [q04_right_triangle.cpp](set1_formulas_conversions/q04_right_triangle.cpp) - Right triangle board
- [q05_cube_box.cpp](set1_formulas_conversions/q05_cube_box.cpp) - Cube box volume
- [q06_cuboid_tank.cpp](set1_formulas_conversions/q06_cuboid_tank.cpp) - Cuboid tank volume
- [q07_cone_volcano.cpp](set1_formulas_conversions/q07_cone_volcano.cpp) - Cone volcano volume
- [q08_sphere_football.cpp](set1_formulas_conversions/q08_sphere_football.cpp) - Sphere football volume
- [q09_c_to_f.cpp](set1_formulas_conversions/q09_c_to_f.cpp) - Celsius to Fahrenheit
- [q10_f_to_c.cpp](set1_formulas_conversions/q10_f_to_c.cpp) - Fahrenheit to Celsius
- [q11_c_to_k.cpp](set1_formulas_conversions/q11_c_to_k.cpp) - Celsius to Kelvin
- [q12_k_to_c.cpp](set1_formulas_conversions/q12_k_to_c.cpp) - Kelvin to Celsius
- [q13_k_to_f.cpp](set1_formulas_conversions/q13_k_to_f.cpp) - Kelvin to Fahrenheit
- [q14_f_to_k.cpp](set1_formulas_conversions/q14_f_to_k.cpp) - Fahrenheit to Kelvin
- [q15_simple_interest.cpp](set1_formulas_conversions/q15_simple_interest.cpp) - Simple interest
- [q16_student_result.cpp](set1_formulas_conversions/q16_student_result.cpp) - Student result
- [q17_train_platform.cpp](set1_formulas_conversions/q17_train_platform.cpp) - Train crossing platform
- [q18_rectangle_garden_cm.cpp](set1_formulas_conversions/q18_rectangle_garden_cm.cpp) - Rectangle garden (input in cm, output in m and inch)
- [q19_square_playground_cm.cpp](set1_formulas_conversions/q19_square_playground_cm.cpp) - Square playground (input in cm, output in m and inch)
- [q20_circle_fountain_cm.cpp](set1_formulas_conversions/q20_circle_fountain_cm.cpp) - Circle fountain (input in cm, output in m and inch)
- [q21_right_triangle_cm.cpp](set1_formulas_conversions/q21_right_triangle_cm.cpp) - Right triangle board (input in cm, output in m and inch)
- [q22_cube_box_cm.cpp](set1_formulas_conversions/q22_cube_box_cm.cpp) - Cube box volume (input in cm, output in m and inch)
- [q23_cuboid_tank_cm.cpp](set1_formulas_conversions/q23_cuboid_tank_cm.cpp) - Cuboid tank volume (input in cm, output in m and inch)
- [q24_cone_volcano_cm.cpp](set1_formulas_conversions/q24_cone_volcano_cm.cpp) - Cone volcano volume (input in cm, output in m and inch)
- [q25_sphere_football_cm.cpp](set1_formulas_conversions/q25_sphere_football_cm.cpp) - Sphere football volume (input in cm, output in m and inch)

## Set 2 - If-Else and Decision Making

- [q01_bank_balance.cpp](set2_if_else/q01_bank_balance.cpp) - Bank Balance Status
- [q02_bill_divisibility.cpp](set2_if_else/q02_bill_divisibility.cpp) - Bill Divisibility
- [q03_voting_eligibility.cpp](set2_if_else/q03_voting_eligibility.cpp) - Voting Eligibility
- [q04_even_or_odd.cpp](set2_if_else/q04_even_or_odd.cpp) - Even or Odd
- [q05_higher_score.cpp](set2_if_else/q05_higher_score.cpp) - Higher Score
- [q06_profit_or_loss.cpp](set2_if_else/q06_profit_or_loss.cpp) - Profit or Loss
- [q07_highest_of_three.cpp](set2_if_else/q07_highest_of_three.cpp) - Highest of Three
- [q08_vowel_or_consonant.cpp](set2_if_else/q08_vowel_or_consonant.cpp) - Vowel or Consonant
- [q09_multiple_of_2_or_3.cpp](set2_if_else/q09_multiple_of_2_or_3.cpp) - Multiple of 2, 3 or Both
- [q10_grade_generator.cpp](set2_if_else/q10_grade_generator.cpp) - Automatic Grade Generator
- [q11_voting_and_senior.cpp](set2_if_else/q11_voting_and_senior.cpp) - Voting + Senior Citizen
- [q12_highest_of_four.cpp](set2_if_else/q12_highest_of_four.cpp) - Highest of Four Teams
- [q13_triangle_type.cpp](set2_if_else/q13_triangle_type.cpp) - Triangle Type
- [q14_electricity_bill.cpp](set2_if_else/q14_electricity_bill.cpp) - Electricity Bill
- [q15_character_classifier.cpp](set2_if_else/q15_character_classifier.cpp) - Character Classifier
- [q16_case_converter.cpp](set2_if_else/q16_case_converter.cpp) - Case Converter

## Set 3 - Switch-Case

- [q01_weekly_planner.cpp](set3_switch_case/q01_weekly_planner.cpp) - The Weekly Planner
- [q02_pocket_calculator.cpp](set3_switch_case/q02_pocket_calculator.cpp) - The Pocket Calculator
- [q03_english_learning_assistant.cpp](set3_switch_case/q03_english_learning_assistant.cpp) - The English Learning Assistant
- [q04_smart_traffic_signal.cpp](set3_switch_case/q04_smart_traffic_signal.cpp) - Smart Traffic Signal
- [q05_shape_calculator.cpp](set3_switch_case/q05_shape_calculator.cpp) - The Architect's Shape Calculator
- [q06_unit_conversion_desk.cpp](set3_switch_case/q06_unit_conversion_desk.cpp) - The Unit Conversion Desk
- [q07_engineering_measurement.cpp](set3_switch_case/q07_engineering_measurement.cpp) - The Engineering Measurement Assistant
- [q08_nava_ratnas_final_position.cpp](set3_switch_case/q08_nava_ratnas_final_position.cpp) - King Vikramaditya's Nava Ratnas - Final Position

## Set 4 - GOTO Logical Practice Lab

- [q01_sensor_monitoring.cpp](set4_goto/q01_sensor_monitoring.cpp) - The Sensor Monitoring System
- [q02_attendance_counter.cpp](set4_goto/q02_attendance_counter.cpp) - The Attendance Counter
- [q03_production_totalizer.cpp](set4_goto/q03_production_totalizer.cpp) - The Production Totalizer
- [q04_quality_analysis.cpp](set4_goto/q04_quality_analysis.cpp) - The Quality Analysis System
- [q05_number_guessing_game.cpp](set4_goto/q05_number_guessing_game.cpp) - The Number Guessing Game
- [q06_secret_vault_password.cpp](set4_goto/q06_secret_vault_password.cpp) - Secret Vault Password
- [q07_target_number_challenge.cpp](set4_goto/q07_target_number_challenge.cpp) - Target Number Challenge
- [q08_digital_sum.cpp](set4_goto/q08_digital_sum.cpp) - Digital Sum

## Run a file

```bash
g++ set2_if_else/q01_bank_balance.cpp -o q01 && ./q01
```
(On Windows use `q01.exe`.)
